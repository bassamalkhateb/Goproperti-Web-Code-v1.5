(function($) {
    "use strict";
    $(function() {
        $('#timeline-2').timeliny({
            hideBlankYears: true
        });
    });
})(jQuery);