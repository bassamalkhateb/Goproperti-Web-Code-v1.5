<?php
namespace Twilio\Rest;

class Intelligence extends IntelligenceBase {
}
